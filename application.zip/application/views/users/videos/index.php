<div class="container-fluid bg-light">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                   <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>
        </div>

        <div class="container-fluid bg-light">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                   <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>

            <div class="col-md-3 col-sm-6 col-xs-6" style="margin:0px"> <!-- class="embed-responsive embed-responsive-16by9" -->
            
                <iframe width="" height="" allowfullscreen
                    src="<?= 'https://www.youtube.com/embed/8QLPnsldo8w' ?>" class="embed-responsive-item">
                    
                </iframe> 
                    <p style="margin: 0px"></p>
                    <img src="<?= base_url()?>assets/image/amin.jpg" width="30px" class="rounded-circle border-success" alt="W">
                <a href="" style="" class="text-left card-link card-text"> <strong> Hello world Hello world Hello world Hello world </strong> </a>
            </div>
        </div>
    </div>
<h1>    <?php echo $this->session->userdata('user_id') ?></h1>
<h1>    <?php echo $this->session->userdata('username') ?></h1>
<h1>    <?php echo $this->session->userdata('password') ?></h1>
</body>
</html>