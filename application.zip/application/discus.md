##  ##
1. Mobile Apps. //Rakib
2. Message notification // Robiul
3. Cloudflier //Mahid
4. First Page header will be seperated //Robiul
5. Post a privery add // Tanim
6. Hover withe or remove or text will white
7. Post Success message will delevered
8. show who people like
9. sticker
10. online live
11. profile privecy.
12. s
