<?php 
											if($quran_gpa == 0){
												$fail1 = 1;
											}else{
												$fail1 = 0;
											}
											
											if($hadith_gpa == 0){
												$fail2 = 1;
											}else{
												$fail2 = 0;
											}
											
											if($arabic1st_gpa == 0){
												$fail3 = 1;
											}else{
												$fail3 = 0;
											}
											
											if($arabic2nd_gpa == 0){
												$fail4 = 1;
											}else{
												$fail4 = 0;
											}
											
											if($fiqh_gpa == 0){
												$fail5 = 1;
											}else{
												$fail5 = 0;
											}
											
											if($bangla1_gpa == 0){
												$fail6 = 1;
											}else{
												$fail6 = 0;
											}
											
											if($bangla2_gpa == 0){
												$fail7 = 1;
											}else{
												$fail7 = 0;
											}
											
											if($english1st_gpa == 0){
												$fail8 = 1;
											}else{
												$fail8 = 0;
											}
											
											if($english2nd_gpa == 0){
												$fail9 = 1;
											}else{
												$fail9 = 0;
											}
											
											if($math_gpa == 0){
												$fail10 = 1;
											}else{
												$fail10 = 0;
											}
											
											if($ph_gpa == 0){
												$fail11 = 1;
											}else{
												$fail11 = 0;
											}
											
											if($ch_gpa == 0){
												$fail12 = 1;
											}else{
												$fail12 = 0;
											}
											
											if($bio_gpa == 0){
												$fail13 = 1;
											}else{
												$fail13 = 0;
											}
											
											$total_fail = $fail1 + $fail2 + $fail3 + $fail4 + $fail5 + $fail6 + $fail7 + $fail8 + $fail9 + $fail10 + $fail11 + $fail12 + $fail12;
?>