<?php
	
date_default_timezone_set("Asia/Dhaka");
echo "The time is " . date("d-m-y h:i:s A");

?>