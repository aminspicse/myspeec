		<div class="left-container" id="left-container">
		  <!-- begin SIDE NAV USER PANEL -->
		    <div class="left-sidebar" id="show-nav">
				<ul id="side" class="side-nav">
				    <li class="panel">
						<a id="panel1" href="javascript:;" data-toggle="collapse" data-target="#Dashboard"> <i class="fa fa-street-view "></i> Primary
						  <i class="fa fa-chevron-left pull-right" id="arow1"></i> </a>
						<ul class="collapse nav" id="Dashboard">
							<li onclick="play()"><a><i class="fa fa-angle-double-right"></i> Class Play</a></li>
							<li onclick="nursary()"><a><i class="fa fa-angle-double-right"></i> Class Nursary</a></li>
							<li onclick="one()"><a><i class="fa fa-angle-double-right"></i> Class One</a></li>
							<li onclick="two()"><a><i class="fa fa-angle-double-right"></i> Class Two</a></li>
							<li onclick="three()"><a><i class="fa fa-angle-double-right"></i> Class Three</a></li>
							<li onclick="four()"><a><i class="fa fa-angle-double-right"></i> Class Four</a></li>
							<li onclick="five()"><a><i class="fa fa-angle-double-right"></i> Class Five</a></li>
							
						</ul>
				    </li>
					<li class="panel">
						<a id="panel1-1" href="javascript:;" data-toggle="collapse" data-target="#Secondary"> <i class="fa fa-male"></i> Secondary
						  <i class="fa fa-chevron-left pull-right" id="arow1-1"></i> </a>
						<ul class="collapse nav" id="Secondary">
							<li onclick="six()"> <a><i class="fa fa-angle-double-right"></i> Class Six</a> </li>
							<li onclick="seven()"> <a><i class="fa fa-angle-double-right"></i>Class Seven </a> </li>
							<li onclick="eight()"> <a><i class="fa fa-angle-double-right"></i>Class  Eight</a> </li>
							<li onclick="nine()"> <a><i class="fa fa-angle-double-right"></i>Class  Nine</a> </li>
							<li onclick="ten()"> <a><i class="fa fa-angle-double-right"></i>Class  Ten</a> </li>
						</ul>
				    </li>
				    <li class="panel">
						<a id="panel2" href="javascript:;" data-toggle="collapse" data-target="#charts"> <i class="fa fa-bar-chart-o"></i> Charts
						  <i class="fa fa-chevron-left pull-right" id="arow2"></i> </a>
						<ul class="collapse nav" id="charts">
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i> Student</a> </li>
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i> Teachers</a> </li>
						</ul>
				    </li>
					<li class="panel">
						<a id="panel20" href="javascript:;" data-toggle="collapse" data-target="#admission"> <i class="fa fa-address-book"></i> Admission
						  <i class="fa fa-chevron-left pull-right" id="arow20"></i> </a>
						<ul class="collapse nav" id="admission">
						  <li> <a href="../admission/admission_form.php" target="_new"><i class="fa fa-angle-double-right text-info"></i> Take Admission</a> </li>
						  <li> <a href="../admission/view_admission.php"  target="_new"><i class="fa fa-angle-double-right"></i>View Admission</a> </li>
						  
						</ul>
					</li>
				    <li class="panel">
						<a id="panel3" href="javascript:;" data-toggle="collapse" data-target="#calendar"> <i class="fa fa-plus-circle"></i> Result Process
						<i class="fa fa-chevron-left pull-right" id="arow3"></i> </a>
						<ul class="collapse nav" id="calendar">
						    <li> <a href="../marksheet-others/process.php" target="_new"><i class="fa fa-angle-double-right"></i>Process Status</a> </li>
						</ul>
				    </li>
					<li class="panel">
						<a id="panel4" href="javascript:;" data-toggle="collapse" data-target="#clipboard"> <i class="fa fa-wifi"></i> Published Result
						  <i class="fa fa fa-chevron-left pull-right" id="arow4"></i> </a>
						<ul class="collapse nav" id="clipboard">
							<li> <a href="../marksheet-others/result_summary_form.php" target="_new"><i class="fa fa-angle-double-right"></i>Result Summary</a> </li>
							<li> <a href="../marksheet-others/result_summary_form_passed.php" target="_new"><i class="fa fa-angle-double-right"></i>Result Summary(Passed)</a> </li>
							<li> <a href="../marksheet-others/tabulation_form.php" target="_new"><i class="fa fa-angle-double-right"></i>Tabulation Sheet</a> </li>
							
						</ul>
					</li>
				    
				    <li class="panel">
						<a id="panel8" href="javascript:;" data-toggle="collapse" data-target="#paper"> <i class="fa fa-file-word-o"></i> Marksheet
						  <i class="fa fa fa-chevron-left pull-right" id="arow8"></i> </a>
						<ul class="collapse nav" id="paper">
						  <li> <a href="../six-eight-madrasah/marksheet_form.php" target="_blank"><i class="fa fa-angle-double-right"></i>Make Marksheet</a> </li>
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>Testimonial</a> </li>
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>T.C</a> </li>
						</ul>
				    </li>
					
					<li class="panel">
						<a id="panel5" href="javascript:;" data-toggle="collapse" data-target="#edit"> <i class="fa fa-book"></i> Routin & Sylabes
						  <i class="fa fa fa-chevron-left pull-right" id="arow5"></i>
						</a>
						<ul class="collapse nav" id="edit">
						  <li> <a href="../routin/class_routin.php" target="_blank"><i class="fa fa-angle-double-right"></i>Make Routin</a> </li>
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>Sylebas</a> </li>
						  <li> <a href="../routin/routin_form.php" target="_blank"><i class="fa fa-angle-double-right"></i>Print Routin</a> </li>
						  <li> <a href="../sylabes/six_school_entry.php" target="_blank"><i class="fa fa-angle-double-right"></i>Make Sylebas</a> </li>
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>Print Sylebas</a> </li>
						</ul>
				    </li>
				    <li class="panel">
						<a id="panel6" href="javascript:;" data-toggle="collapse" data-target="#inbox"> <i class="fa fa-id-card"></i> ID Card
						  <i class="fa fa fa-chevron-left pull-right" id="arow6"></i> </a>
						<ul class="collapse nav" id="inbox">
						  <li> <a href="../idcard/id.php" target='_blank'><i class="fa fa-angle-double-right"></i>Make ID Card</a> </li>
						  
						</ul>
				    </li>
				    <li class="panel">
						<a id="panel7" href="javascript:;" data-toggle="collapse" data-target="#cogs"> <i class="fa fa-credit-card"></i> Payments
						  <i class="fa fa fa-chevron-left pull-right" id="arow7"></i> </a>
						<ul class="collapse nav" id="cogs">
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>Non Functional</a> </li>
						  
						</ul>
				    </li>
					
				    <li class="panel">
						<a id="panel9" href="javascript:;" data-toggle="collapse" data-target="#trash"> <i class="fa fa-trash"></i> Trash
						  <i class="fa fa fa-chevron-left pull-right" id="arow9"></i>
						</a>
						<ul class="collapse nav" id="trash">
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>Non Functional</a> </li>
						  
						</ul>
				    </li>
				    <li class="panel">
						<a id="panel10" href="javascript:;" data-toggle="collapse" data-target="#btc">
						  <i class="fa fa-btc"></i> paper
						  <i class="fa fa fa-chevron-left pull-right" id="arow10"></i>
						</a>
						<ul class="collapse nav" id="btc">
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>Non Functional</a> </li>
						  
						</ul>
				    </li>
				    <li class="panel">
						<a id="panel11" href="javascript:;" data-toggle="collapse" data-target="#pie-Chart">
						  <i class="fa fa-bar-chart"></i> Chart
						  <span class="label label-success">Non Functional</span> <i class="fa fa fa-chevron-left pull-right" id="arow11"></i> </a>
						<ul class="collapse nav" id="pie-Chart">
						  <li> <a href="#"><i class="fa fa-angle-double-right"></i>Non Functional</a> </li>
						  
						</ul>
				    </li>
				</ul>
		    </div>
		</div>
		<!-- END SIDE NAV USER PANEL -->
	<script>
	$(document).ready(function() {
      $("#panel1").click(function() {
        $("#arow1").toggleClass("fa-chevron-left");
        $("#arow1").toggleClass("fa-chevron-down");
      });
        
      $("#panel2").click(function() {
        $("#arow2").toggleClass("fa-chevron-left");
        $("#arow2").toggleClass("fa-chevron-down");
      });
        
      $("#panel3").click(function() {
        $("#arow3").toggleClass("fa-chevron-left");
        $("#arow3").toggleClass("fa-chevron-down");
      });
        
      $("#panel4").click(function() {
        $("#arow4").toggleClass("fa-chevron-left");
          $("#arow4").toggleClass("fa-chevron-down");
      });
        
      $("#panel5").click(function() {
        $("#arow5").toggleClass("fa-chevron-left");
        $("#arow5").toggleClass("fa-chevron-down");
      });
        
      $("#panel6").click(function() {
        $("#arow6").toggleClass("fa-chevron-left");
        $("#arow6").toggleClass("fa-chevron-down");
      });
        
      $("#panel7").click(function() {
        $("#arow7").toggleClass("fa-chevron-left");
        $("#arow7").toggleClass("fa-chevron-down");
      });
        
      $("#panel8").click(function() {
        $("#arow8").toggleClass("fa-chevron-left");
        $("#arow8").toggleClass("fa-chevron-down");
      });
        
      $("#panel9").click(function() {
        $("#arow9").toggleClass("fa-chevron-left");
        $("#arow9").toggleClass("fa-chevron-down");
      });
        
      $("#panel10").click(function() {
        $("#arow10").toggleClass("fa-chevron-left");
        $("#arow10").toggleClass("fa-chevron-down");
      });
        
      $("#panel11").click(function() {
        $("#arow11").toggleClass("fa-chevron-left");
        $("#arow11").toggleClass("fa-chevron-down");
      });
	  
	  $("#panel20").click(function() {
        $("#arow20").toggleClass("fa-chevron-left");
        $("#arow20").toggleClass("fa-chevron-down");
      });
        
      $("#menu-icon").click(function() {
        $("#chang-menu-icon").toggleClass("fa-bars");
        $("#chang-menu-icon").toggleClass("fa-times");
        $("#show-nav").toggleClass("hide-sidebar");
        $("#show-nav").toggleClass("left-sidebar");
          
        $("#left-container").toggleClass("less-width");
        $("#right-container").toggleClass("full-width");
      });
        
     
        
    });
</script>