<?php 
	include '../elements/simpleheader.php';
?>
				<br />
				<br />
				<br />
				<br />
			<div class="row">
				<h2 class="text-center text-danger">Your Requested Page is Not Found</h2>
			</div>
			<div class="row">
				<h1 class="text-center"><a href="../index.php">Goto Home Page</a></h1>
			</div>
			
			<div class="row">
				<h2 class="text-center"><a href="www.facebook.com/picosoftbd">Help Our Facebook Page</a></h2>
			</div>
		</body>
	</html>