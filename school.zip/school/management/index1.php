
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="MD. AL AMIN">
	<title>admin-Pannel</title>
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="css/style.css" rel="stylesheet" type="text/css">
	<link href="css/admin.css" rel="stylesheet" type="text/css">
	<script src="js/07b0ce5d10.js"></script>
	<script src="js/jquery.js"></script>
	<script src="js/jquery3.1.1.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>
	<div class="container-fluid">
		<br><br><br><br><br><br><br>
		<div class="row">
			<h3 class="text-center">School Management System Bangladesh<h3>
		</div>

		<div class="row text-center">
			<div class="col-md-6 col-md-offset-3">
				<img src="bijoydibos.jpg" style=" height: 200px ">
			</div>
		</div>

		<div class="row">
			<div class="col-md-3 col-md-offset-3">
				<div class="thumbnail">
					<a href="index.php"><h2 class="text-center">Admin Login</h2></a>
				</div>
			</div>
			<div class="col-md-3">
				<div class="thumbnail">
					<a href="student login/index.php"><h2 class="text-center">Student Login</h2></a>
				</div>
			</div>
		</div>
		
		<br><br><br><br><br>
		<div class="footer">
			<footer class="panel-footer fixed-">
				<a href="http://www.facebook.com/picosoftbd" target="_blank">Facebook</a>
			</footer>
		</div>
	</div>
</body>	