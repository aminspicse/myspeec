<!DOCTYPE html>
<html>
	<head>
		<link type="text/css" rel="stylesheet" href="../css/bootstrap.min.css">
		<link href="image_upload_plugin/dist/css/bootstrap-imageupload.css" rel="stylesheet">
		<!-- <link type="text/css" rel="stylesheet" href="register.css"> -->
		<script type="text/javascript" src="../js/jquery.js"> </script>
		<script type="text/javascript" src="../js/bootstrap.min.js"></script>
		<script type="text/javascript" src="register.js"></script>
		<script type="text/javascript" src="location.js"></script>
	</head>
	<body class="container-fluid" style="background:#eee">
		<h4>If Need Any Help Please Contact: +880 1931-724729 or aminspicse@gmail.com</h4>
	</body>
</html>