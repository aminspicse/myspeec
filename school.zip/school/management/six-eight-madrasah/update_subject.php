
 
		<div class="col-md-11 col-lg-10 col-sm-10 col-xs-12 col-md-offset-1 col-lg-offset-1 col-sm-offset-1">
			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>1. Quran Mazid:</h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="quran_mcq" value ="<?php echo $rows['quran_mcq'] ?>" placeholder="MCQ " class="form-control leng" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="quran_wr" value ="<?php echo $rows['quran_wr'] ?>" placeholder="WR " class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="quran_incourse" value ="<?php echo $rows['quran_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="quran_total" value ="<?php echo $rows['quran_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="quran_gread" value ="<?php echo $rows['quran_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="quran_status" value ="<?php echo $rows['quran_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>

			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>2. Arabic 1<sup>st</sup> Paper:</h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1" ><input type="text" name="" value ="" placeholder="None" class="form-control" disabled maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="arabic1st" value ="<?php echo $rows['arabic1st'] ?>" placeholder="Arabic 1st" class="form-control" maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="arabic1st_incourse" value ="<?php echo $rows['arabic1st_incourse'] ?>" placeholder="Icourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="arabic_gpa" value ="<?php echo $rows['arabic1st_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="arabic_gpa" value ="<?php echo $rows['arabic1st_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="arabic_status" value ="<?php echo $rows['arabic1st_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			
			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>3. Arabic 2<sup>nd</sup> Paper:</h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1" ><input type="text" name="" value ="" disabled placeholder="None" class="form-control" maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="arabic2nd" value ="<?php echo $rows['arabic2nd'] ?>" placeholder="Arabic 2nd" class="form-control" maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="arabic2nd_incourse" value ="<?php echo $rows['arabic2nd_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="arabic2nd_total" value ="<?php echo $rows['arabic2nd_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="arabic2nd_gpa" value ="<?php echo $rows['arabic2nd_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="arabic2nd_status" value ="<?php echo $rows['arabic2nd_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>

			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>4. Aqaid and Fiqh: </h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="aqaid_mcq" value ="<?php echo $rows['aqaid_mcq'] ?>" placeholder="MCQ" class="form-control"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="aqaid_wr" value ="<?php echo $rows['aqaid_wr'] ?>" placeholder="CQ" class="form-control" maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="aqaid_incourse" value ="<?php echo $rows['aqaid_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="aqaid_total" value ="<?php echo $rows['aqaid_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="aqaid_gpa" value ="<?php echo $rows['aqaid_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="aqaid_status" value ="<?php echo $rows['aqaid_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>

			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>5. Bangla:</h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="" value ="" placeholder="None" disabled class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="bangla" value ="<?php echo $rows['bangla'] ?>" placeholder="Bang." class="form-control" maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="bangla_incourse" value ="<?php echo $rows['bangla_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="bangla_total" value ="<?php echo $rows['bangla_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="bangla_gpa" value ="<?php echo $rows['bangla_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="bangla_status" value ="<?php echo $rows['bangla_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			
			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>6. English: </h4></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="" value ="" placeholder="None" class="form-control" disabled maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="english" value ="<?php echo $rows['english'] ?>" placeholder="Eng." class="form-control" maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="english_incourse" value ="<?php echo $rows['english_incourse'] ?>" placeholder="Incourse" maxlength="2" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="english_total" value ="<?php echo $rows['english_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="english_gpa" value ="<?php echo $rows['english_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="english_status" value ="<?php echo $rows['english_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			
			<div class="row form-group bg-difault">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>7. General Mathmatic :</h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="math_mcq" value ="<?php echo $rows['math_mcq'] ?>" placeholder="MCQ" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="math_wr" value ="<?php echo $rows['math_wr'] ?>" placeholder="CQ" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="math_incourse" value ="<?php echo $rows['math_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="math_total" value ="<?php echo $rows['math_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="math_gpa" value ="<?php echo $rows['math_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="math_status" value ="<?php echo $rows['math_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>8. General Science : </h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="science_mcq" value ="<?php echo $rows['science_mcq'] ?>" placeholder="MCQ" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="science_wr" value ="<?php echo $rows['science_wr'] ?>" placeholder="CQ " class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="science_incourse" value ="<?php echo $rows['science_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="science_total" value ="<?php echo $rows['science_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1d-1"><input type="text" name="science_gpa" value ="<?php echo $rows['science_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1d-1"><input type="text" name="science_status" value ="<?php echo $rows['science_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>9. Bangladesh & Global Studies: </h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="bgs_mcq" value ="<?php echo $rows['bgs_mcq'] ?>" placeholder="MCQ" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="bgs_wr" value ="<?php echo $rows['bgs_wr'] ?>" placeholder="CQ" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="bgs_incourse" value ="<?php echo $rows['bgs_incourse'] ?>" placeholder="Incourse" class="form-control" maxlength="2"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="bgs_total" value ="<?php echo $rows['bgs_total'] ?>" placeholder=" Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="bgs_gpa" value ="<?php echo $rows['bgs_gpa'] ?>" placeholder=" GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="bgs_status" value ="<?php echo $rows['bgs_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>

			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>10. Information & <abbr title="Communicaton">C</abbr> Technology:</h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="" value ="<?php ?>" placeholder="None" disabled class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="ict" value ="<?php echo $rows['ict'] ?>" placeholder="ICT" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="ict_incourse" value ="<?php echo $rows['ict_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="ict_total" value ="<?php echo $rows['ict_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="ict_gpa" value ="<?php echo $rows['ict_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="ict_status" value ="<?php echo $rows['ict_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			
			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4"><h4>11. <select class="form-control" name="extra_subject"><option value ="<?php echo $rows['extra_subject'] ?>"><?php echo $rows['extra_subject'] ?></option><option value="Agricultural Studies">Agricultural Studies</option><option value="Domestic Education">Domestic Education</option></select> </h4> </div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="extra_mcq" value ="<?php echo $rows['extra_mcq'] ?>" placeholder="MCQ" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="extra_wr" value ="<?php echo $rows['extra_wr'] ?>" placeholder="CQ" class="form-control" maxlength="2"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="extra_incourse" value ="<?php echo $rows['extra_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="extra_total" value ="<?php echo $rows['extra_total'] ?>" placeholder=" Total" class="form-control" disabled></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="extra_gpa" value ="<?php echo $rows['extra_gpa'] ?>" placeholder=" GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="extra_status" value ="<?php echo $rows['extra_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			
			<div class="row form-group">
				<div class="col-md-4 col-sm-4 col-lg-4-md-4"><h4>12. 
					<select class="form-control" name="pt_subject">
						<option value="<?php echo $rows['pt_subject'] ?>"><?php echo $rows['pt_subject'] ?></option>
						<option value="PHY. EDU & HYGIENE">PHY. EDU & HYGIENE</option>
						<option value="Work & L O Education">Work & L O Education</option>
					</select> </h4> 
				</div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="" placeholder="None" disabled class="form-control"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="pt" value ="<?php echo $rows['pt'] ?>" placeholder="Mark" class="form-control" maxlength="3"></div>
				<div class="col-md-1 col-xs-4 col-sm-2 col-lg-1"><input type="text" name="pt_incourse" value ="<?php echo $rows['pt_incourse'] ?>" placeholder="Incourse" class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="pt_gpa" value ="<?php echo $rows['pt_total'] ?>" placeholder="Total" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="pt_gread" value ="<?php echo $rows['pt_gpa'] ?>" placeholder="GPA" disabled class="form-control"></div>
				<div class="col-md-1 hidden-sm hidden-xs col-lg-1"><input type="text" name="pt_status" value ="<?php echo $rows['pt_status'] ?>" placeholder="Status" disabled class="form-control"></div>
			</div>
			
			<div class="row ">
				<div class="col-md-6 col-md-offset-3">
					<button id="submit" type="submit" name="submit" class="btn btn-block btn-lg btn-info">Update</button>
				</div>
			</div>
		</div>