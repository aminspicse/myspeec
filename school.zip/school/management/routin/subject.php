		<!--Assending By Charecter-->
		<option value="">None</option>
		<option value="Arabic 1st">Arabic 1st</option>
		<option value="Arabic 2nd">Arabic 2nd</option>
		<option value="Agricultural Studies">Agricultural Studies</option>

		<option value="Bangla 1st">Bangla 1st</option>
		<option value="Bangla 1st">Bangla 2nd</option>
		<option value="Biology ">Biology </option>

		<option value="Chemistry">Chemistry</option>
		<option value="Caro and Karo Kola">Caro and Karo Kola</option>

		<option value="English 1st">English 1st</option>
		<option value="English 1st">English 2nd</option>

		<option value="Fiqh & U.Fiqh">Fiqh & U.Fiqh</option>

		<option value="General Science">General Science</option>

		<option value="Hadith Sharif">Hadith Sharif</option>
		<option value="Health Education">Health Education</option>
		<option value="Higer Mathmatic">Higer Mathmatic</option>
		<option value="History">History</option>

		<option value="ICT">ICT</option>
		<option value="Islamic History">Islamic History</option>

		<option value="Mathmatic">Mathmatic</option>
		
		<option value="Physics">Physics</option>
		<option value="Physical Education">Physical Education</option>

		<option value="Quran Mazid">Quran Mazid</option>

		<option value="Religious and Moral Studies">Religious and Moral Studies</option>

		<option value="Social Science">Social Science</option>
		
		
		<option value="Work & L O Education">Work & L O Education</option>
		
		<option value=""></option>
		<option value=""></option>
