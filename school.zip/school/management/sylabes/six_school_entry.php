<?php 

	include '../elements/simpleheader.php';
	//echo "Hello bangladesh";
?>
	
	<div class="container">
		<form action="" method="">
			<div class="row text-center">
				<h2 class="text-center"><?php echo $ses['school_name']?></h2>
			</div>
			<div class="row"><h1 class="text-center">Sylabes Is Under Construction</h1></div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" class="form-control" name="" placeholder="Subject name">
				</div>
				
			</div>
		</form>
	</div>
		
	</body>
</html>