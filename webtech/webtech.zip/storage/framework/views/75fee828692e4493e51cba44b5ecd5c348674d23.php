<?php $__env->startSection('content'); ?>
<div class="row text-center">	
	<div class="col-md">
		<h1>Do You Have Any Problem? Feel Free To Share With Us</h1>
	</div>
</div><br>
<div class="row">
	<div class="col-md-8">
		<div class="card">
			<?php 
				$exception = Session::get('exception');
				$message = Session::get('message');
			?>
			<?php if($exception): ?>
			<div class="alert alert-success alert-dismissible fade show" role="alert">
				  <button type="button" class="close" data-dismiss="alert">
				    <span aria-hidden="true">&times;</span>
				  </button>
				  <strong>
				  	<?php echo $exception;Session::put('exception',null);?>
					
				  </strong>
			</div>
			<?php endif; ?>
			<form action="<?php echo e(route('send.message')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<div class="card-body">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>Name</label>
							<input type="text" name="person_name" class="form-control" placeholder="Enter Your Name" required="">
						</div>
					</div>		
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>E-mail</label>
							<input type="email" name="person_email" class="form-control" placeholder="example@gmail.com" required>
						</div>
					</div>		
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>Message</label>
							
							<input type="text" name="person_message" class="form-control" required>
						</div>
					</div>		
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<button type="submit" class="btn btn-info" name="submit">Send Message</button>
						</div>
					</div>		
				</div>
			</div>
			</form>
		</div>
	</div>
	<div class="col-md-4">
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publiclayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>