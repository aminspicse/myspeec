<?php $__env->startSection('content'); ?>
<div class="container">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<h4 class="pull-left page-title">Welcome !</h4>
			<ol class="breadcrumb pull-right">
				<li><a href="#">Web TechBD</a></li>
				<li class="active">IT</li>
			</ol>
		</div>
	</div>

	<!-- Start Widget -->
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">Our Students</h3>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<table id="datatable" class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>Name</th>
										<th>Phone</th>
										<th>Address</th>
										<th>Image</th>
										<th>Course</th>
										<th>Action</th>
									</tr>
								</thead>


								<tbody>
									<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($row->name); ?></td>
										<td><?php echo e($row->student_phone); ?></td>
										<td><?php echo e($row->present_address); ?></td>
										<td><img src="<?php echo e($row->student_photo); ?>" style="height: 60px; width: 60px;"></td>
										<td><?php echo e($row->course_name); ?></td>
										<td>
											<a href="<?php echo e(URL::to('edit-student/'.$row->id)); ?>" class="btn btn-sm btn-info">Edit</a>
											<a href="<?php echo e(URL::to('view-student/'.$row->id)); ?>" class="btn btn-sm btn-primary">View</a>
											<a href="<?php echo e(URL::to('delete-student/'.$row->id)); ?>" class="btn btn-sm btn-danger" id="delete">Delete</a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admindash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>