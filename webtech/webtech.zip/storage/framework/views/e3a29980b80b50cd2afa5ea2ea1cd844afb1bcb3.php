<?php $__env->startSection('content'); ?>
<!-- Page-Title -->
<div class="row">
    <div class="col-sm-12">
        <h4 class="pull-left page-title">Welcome !</h4>
        <ol class="breadcrumb pull-right">
            <li><a href="<?php echo e(route('home')); ?>">Web TechBD</a></li>
            <li class="active">Dashboard</li>
        </ol>
    </div>
</div>

<!-- Start Widget -->
<?php if(Auth::user()->student_status == 0): ?>
<div class="row">
    <div class="col-md-8 col-sm-8 col-lg-8">
        <div class="mini-stat clearfix bx-shadow">
            <span class="mini-stat-icon bg-success"><i class="fa fa-check"></i></span>
            <div class="tiles-progress">
                <div class="m-t-20">
                    <h4>Registration Success Wait For Our Confirmation</h4>
                    <i>We Will Get Back To You Soon.</i>
                </div>
            </div>
        </div>
    </div>
</div> 
<!-- End row-->
<?php else: ?>
<div class="row">
    <div class="col-md-8 col-sm-8 col-lg-8">
        <div class="mini-stat clearfix bx-shadow">
            <span class="mini-stat-icon bg-success"><i class="fa fa-check"></i></span>
            <div class="tiles-progress">
                <div class="m-t-20">
                    <h4><a href="<?php echo e(route('download.myform')); ?>" class="btn btn-success">Download Form</a></h4>
                    <i>Click Here To Download Your Application Form</i>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
</div> <!-- container -->





</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layfadmin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>