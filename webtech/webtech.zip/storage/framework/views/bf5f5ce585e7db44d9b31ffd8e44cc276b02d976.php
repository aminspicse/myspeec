<?php $__env->startSection('content'); ?>
<div class="container">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<h4 class="pull-left page-title">Welcome !</h4>
			<ol class="breadcrumb pull-right">
				<li><a href="#">Web TechBD</a></li>
				<li class="active">IT</li>
			</ol>
		</div>
	</div>

	<!-- Start Widget -->
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">All Mails</h3>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-md-12 col-sm-12 col-xs-12">
							<table id="datatable" class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>Name</th>
										<th>Email</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>


								<tbody>
									<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($result->sender_name); ?></td>
										<td><?php echo e($result->sender_email); ?></td>
										<td>
											<div class="badge badge-success">READ</div>
										</td>
										<td>
											<a href="<?php echo e(URL::to('view-read-message/'.$result->message_id)); ?>" class="btn btn-sm btn-success">View</a>
											<a href="<?php echo e(URL::to('delete-read-message/'.$result->message_id)); ?>" class="btn btn-sm btn-danger" id="delete">Delete</a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admindash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>