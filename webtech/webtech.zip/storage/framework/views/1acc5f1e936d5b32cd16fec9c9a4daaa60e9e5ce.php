<?php $__env->startSection('content'); ?>
<section class="demo-wrapper" id="demo-top">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2>Our Services</h2>
                <p>We created awesome demos to show you the potentioal off saas app. Easy to import and highly customizable, they make your life easier</p>
            </div>
        </div>
    </div>
    <div class="container lg">
        <ul class="row theme-demo-listing">
            <li class="col-6 col-md-4">
                <div class="top-bar"><img src="<?php echo e(url('public/frontend/images/top-bar.png')); ?>" alt=""></div>
                <div class="thumbnail-holder">
                    <figure><img src="<?php echo e(url('public/frontend/images/index1.jpg')); ?>" alt=""></figure>
                    <div class="mask"> <a href="#" class="ovelay-icon"><span class="icon-go"></span></a> </div>
                </div>
            </li>
            <li class="col-6 col-md-4">
                <div class="top-bar"><img src="<?php echo e(url('public/frontend/images/top-bar.png')); ?>" alt=""></div>
                <div class="thumbnail-holder">
                    <figure><img src="<?php echo e(url('public/frontend/images/index2.jpg')); ?>" alt=""></figure>
                    <div class="mask"> <a href="#" class="ovelay-icon"><span class="icon-go"></span></a> </div>
                </div>
            </li>
            <li class="col-6 col-md-4">
                <div class="top-bar"><img src="<?php echo e(url('public/frontend/images/top-bar.png')); ?>" alt=""></div>
                <div class="thumbnail-holder">
                    <figure><img src="<?php echo e(url('public/frontend/images/index3.jpg')); ?>" alt=""></figure>
                    <div class="mask"> <a href="#" class="ovelay-icon"><span class="icon-go"></span></a> </div>
                </div>
            </li>
            <li class="col-6 col-md-4">
                <div class="top-bar"><img src="<?php echo e(url('public/frontend/images/top-bar.png')); ?>" alt=""></div>
                <div class="thumbnail-holder">
                    <figure><img src="<?php echo e(url('public/frontend/images/index4.jpg')); ?>" class="img-fluid" alt=""></figure>
                    <div class="mask"> <a href="#" class="ovelay-icon"><span class="icon-go"></span></a> </div>
                </div>
            </li>
            <li class="col-6 col-md-4">
                <div class="top-bar"><img src="<?php echo e(url('public/frontend/images/top-bar.png')); ?>" alt=""></div>
                <div class="thumbnail-holder">
                    <figure><img src="<?php echo e(url('public/frontend/images/index5.jpg')); ?>" class="img-fluid" alt=""></figure>
                    <div class="mask"> <a href="#" class="ovelay-icon"><span class="icon-go"></span></a> </div>
                </div>
            </li>
            <li class="col-6 col-md-4">
                <div class="top-bar"><img src="<?php echo e(url('public/frontend/images/top-bar.png')); ?>" alt=""></div>
                <div class="thumbnail-holder">
                    <figure><img src="<?php echo e(url('public/frontend/images/index6.jpg')); ?>" class="img-fluid" alt=""></figure>
                    <div class="mask"> <a href="#" class="ovelay-icon"><span class="icon-go"></span></a> </div>
                </div>
            </li>
        </ul>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publiclayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>