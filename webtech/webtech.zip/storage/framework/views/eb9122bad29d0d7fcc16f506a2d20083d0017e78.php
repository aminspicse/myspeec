<?php $__env->startSection('content'); ?>
<div class="row">
	 <div class="col-md-6">
        <div class="panel panel-default">
             <div class="panel-heading">
             	<h3 class="panel-title">Update Student</h3>
             </div>
             <div class="panel-body">
                 <form  action="<?php echo e(route('set.student')); ?>" method="POST" enctype="multipart/form-data">
                 	<?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Name</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e($result->name); ?>" required="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Father's Name</label>
                        <input type="text" name="student_fname" class="form-control"  value="<?php echo e($result->student_fname); ?>" required="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Mother's Name</label>
                        <input type="text" name="student_mname" class="form-control"  value="<?php echo e($result->student_mname); ?>" required="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Birth Date</label>
                        <input type="date" name="student_birthdate" class="form-control" value="<?php echo e($result->student_birthdate); ?>" required="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Phone</label>
                        <input type="text" name="student_phone" class="form-control" value="<?php echo e($result->student_phone); ?>" required="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email</label>
                        <input type="email" name="email" class="form-control" value="<?php echo e($result->email); ?>" required="1">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Gender</label>
                        <select class="form-control" name="student_gender">
                          <option value="<?php echo e($result->student_gender); ?>" selected="">
                            <?php if($result->student_gender == 1): ?>
                              Male
                            <?php elseif($result->student_gender == 2): ?>
                              Female
                            <?php else: ?>
                              Others
                            <?php endif; ?>
                          </option>
                          <option value="1">Male</option>
                          <option value="2">Female</option>
                          <option value="3">Others</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Address</label>
                        <input type="text" name="present_address" class="form-control" value="<?php echo e($result->present_address); ?>">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Last Education Qualification</label>
                        <input type="text" name="lasteducation" class="form-control" value="<?php echo e($result->lasteducation); ?>">
                    </div>
                    <div class="form-group">
                       <label for="">Course Name</label>
                       <select name="course_id" class="form-control">
                          <?php 
                          $course = DB::table('coursedetails')
                          ->where('course_status',1)
                          ->get();
                          ?>
                          <?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($course->course_id); ?>" <?php if($result->course_id == $course->course_id){echo "selected";} ?>><?php echo e($course->course_name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group">
                       <label for="">Shift</label>
                       <select name="shift_id" class="form-control">
                         <?php 
                             $shift = DB::table('shifts')
                             ->where('shift_status',1)
                             ->get();
                         ?>
                         <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($shift->shift_id); ?>" <?php if($result->shift_id == $shift->shift_id){echo "selected";} ?>><?php echo e($shift->shift_details); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                    </div>
                    <div class="form-group">
                    	<img id="image" src="<?php echo e(url($result->student_photo)); ?>"  height="90px" width="90px" />
                    	<label for="exampleInputPassword11">Photo</label>
                    	<input type="file" name="student_photo" accept="image/*" onchange="readURL(this);">
                      <input type="hidden" name="oldphoto" value="<?php echo e($result->student_photo); ?>">
                      <input type="hidden" name="student_id" value="<?php echo e($result->id); ?>">
                    	<i>Please upload a valid image file. Size of image should not be more than 2MB.</i>
                    </div>
                    <button type="submit" class="btn btn-purple waves-effect waves-light">Update</button>
                 </form>
            </div><!-- panel-body -->
          </div> <!-- panel -->
    </div> <!-- col-->
</div>
<script type="text/javascript">
	function readURL(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $('#image')
                  .attr('src', e.target.result)
                  .width(80)
                  .height(80);
          };
          reader.readAsDataURL(input.files[0]);
      }
   }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admindash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>