<?php $__env->startSection('content'); ?>
<div class="row">
	 <div class="col-md-10">
        <div class="panel panel-default">
             <div class="panel-heading">
             	<h3 class="panel-title">Add Course</h3>
             </div>
             <div class="panel-body">
                 <form  action="<?php echo e(route('create.shift')); ?>" method="POST" enctype="multipart/form-data">
                 	<?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Shift Name & Time</label>
                        <input type="text" name="shift_details" class="form-control" placeholder="Enter Shift" required="1">
                    </div>                    
                    <button type="submit" class="btn btn-purple waves-effect waves-light">Add Shift</button>
                 </form>
            </div><!-- panel-body -->
          </div> <!-- panel -->
    </div> <!-- col-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admindash', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>