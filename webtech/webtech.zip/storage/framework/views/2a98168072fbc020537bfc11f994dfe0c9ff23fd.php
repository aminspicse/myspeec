<!DOCTYPE html>
<html>
<head>
	<title>Send Mail</title>
</head>
<body>
	<?php echo e($mainmessage); ?>

</body>
</html>