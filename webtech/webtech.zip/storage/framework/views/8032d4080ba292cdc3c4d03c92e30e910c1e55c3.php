<?php $__env->startSection('content'); ?>
	<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-md-8 offset-2">
			<div class="card">
				<div class="card-header">
					<h4 class="text-center"><?php echo e($result->course_name); ?></h4>
				</div>
				<div class="card-body">
					<table class="table table-bordered table-dark table-striped" align="center">
							<td><?php $doc =new DOMDocument();$doc->loadHTML($result->course_details);echo $doc->saveHTML() ?></td>
							<td rowspan="10" style="text-align:center;padding-top:5%;"><?php echo e($result->course_duration); ?> <br /><?php echo e($result->course_fee); ?>/=</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</div>
	<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.publiclayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>