@extends('layouts.publiclayout')
@section('content')
<div style="background:#f6f3f3;border:1px solid #ddd9d9;padding:10px;">
    <div class="row text-center"><div class="col-md"><h5>About Us</h5></div></div>
    <br>
    <div class="row">
        <div class="col-md-6">
            <h4>Web Tech BD</h4>
            <p style="font-size:18px" class="text-justify">
                Is a IT Firm. That's provide Many Kind of software services.
                With amazing features, beautiful design and well-thought out demos, Web TechBD is the perfect choice to you.
                With amazing features, beautiful design and well-thought out demos, Web TechBD is the perfect choice to you.
                With amazing features, beautiful design and well-thought out demos, Web TechBD is the perfect choice to you.
                With amazing features, beautiful design and well-thought out demos, Web TechBD is the perfect choice to you.
                With amazing features, beautiful design and well-thought out demos, Web TechBD is the perfect choice to you.
                With amazing features, beautiful design and well-thought out demos, Web TechBD is the perfect choice to you.
            </p>
        </div>
        <div class="col-md-6" style="border-left:1px solid red;">
            <h4>For More Query Visit Our Office</h4>
            <strong>Address: Star View Complex (4th Floor), Varthokola (Station Road),Sylhet.</strong>
            <p style="font-size:18px;">Phone: +8801689-015612</p>
            <div class="tab-content" id="myTabContent">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3619.359642316081!2d91.86451081437157!3d24.885711350375264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3751abff3195ec15%3A0xe9444694d652ddad!2sWeb+Tech+Bd!5e0!3m2!1sen!2sbd!4v1546427363615" width="100%" height="200px" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
            <h3>Like Us On <i class="fa fa-facebook"> </i> : <a href="https://facebook.com/webtecbd">Web TechBD</a></h3>
            <h3>Join Us With <i class="fa fa-youtube"> </i> : <a href="https://facebook.com/webtecbd">Web TechBD</a></h3>
        </div>
    </div>
</div>
@endsection