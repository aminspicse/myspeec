<!DOCTYPE html>
<html>
<head>
	<title>Send Mail</title>
</head>
<body>
	{{$mainmessage}}
</body>
</html>