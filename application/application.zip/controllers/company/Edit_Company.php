<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_Company extends CI_Model{
    public function __construct(){
        parent::__construct();
    }

    public function editdata(){
        echo 'hello ';
    }
}