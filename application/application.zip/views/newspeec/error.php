<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12">
        <p class="text-danger text-center" style="color: red;"><?= $this->upload->display_errors() ?></p>
        </div>
    </div>
</div>