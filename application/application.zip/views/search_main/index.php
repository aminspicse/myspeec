<div class="content-wrapper container">
    <div class="row bg-default">
        <div class="col-md-1">
            <a href="">Posts</a>
        </div>
        <div class="col-md-1">
            <a href="">People</a>
        </div>
        <div class="col-md-1">
            <a href="">Video</a>
        </div>
        <div class="col-md-1">
            <a href="">Image</a>
        </div>
        
    </div>
</div>