
<h1>hello </h1>
</div>
</body>
</html>

<style>
    .widthinput{
        width: 400px;
    }
    
</style>
     
     