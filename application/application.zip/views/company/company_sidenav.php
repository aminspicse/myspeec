<main class="cd-main-content">
		<nav class="cd-side-nav">
			<ul>
				
				<li style="margin-bottom: -20px; margin-left: -20px; margin-top: -20px">
					<a href="<?= base_url('createcompany') ?>" class="card-link" target=""> <i class="fa fa-unlock"></i> Create Company</a>
                </li>
				<li style="margin-bottom: -20px; margin-left: -20px; margin-top: -20px">
					<a href="<?= base_url('createjob') ?>" class="card-link" target=""> <i class="fa fa-unlock"></i> Create Job</a>
				</li>
				<li style="margin-bottom: -20px; margin-left: -20px; margin-top: -20px">
					<a href="<?= base_url('mycompany') ?>" class="card-link" target=""> <i class="fa fa-unlock"></i> My Company</a>
				</li>
			</ul>
				<!--
				<li class="has-children comments">
					<a href="#0">Comments</a>
					
					<ul>
						<li><a href="#0">All Comments</a></li>
						<li><a href="#0">Edit Comment</a></li>
						<li><a href="#0">Delete Comment</a></li>
					</ul>
				</li>
				-->

			<ul class="navbar-nav mr-auto">
				<li class="cd-label">&copy;myspeec-<?= date('y')?></li>
				<li class="action-btn"><a href="" class="card-link">Refresh</a></li>
			</ul>

		</nav>
<!--
		<div class="content-wrapper">
			<h1>Responsive Sidebar Navigation</h1>
		</div>  .content-wrapper -->
<!--	</main> --> <!-- .cd-main-content -->
