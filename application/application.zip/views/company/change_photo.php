
    <form action="" method="post" name="company_photo" enctype="multipart/form-data">
        <input type="file" name="logu">
        <input type="file" name="userfile">
        <button name="save_change">Save Change</button>
    </form>

</div>
</body>
</html>