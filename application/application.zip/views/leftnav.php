<main class="cd-main-content">
		<nav class="cd-side-nav">
			<ul>
				<li class="" style="margin-top: -10px">
					<a href="<?= base_url() ?>Home" class="card-link"> <i class="fa fa-home"></i> Home</a>
					
				</li>
				<li class="" style="margin-top: -10px">
					<a href="<?= base_url() ?>Home/video" class="card-link" target="_new"> <i class="fa fas fa-play"></i> Videos</a>
					
				</li>
				<li class="" style="margin-top: -10px">
					<a href="<?= base_url() ?>NewSpeec/" class="card-link" target="_new"> <i class="fa fa-newspaper"></i> New Speek</a>
					
				</li>
				<li class="">
					<a href="<?= base_url('All_Speaker/index.asp')?>" class="card-link"> <i class="fa fa-user-plus"></i> All Speeker</a>
					
				</li>
			</ul>

			

			<ul>
			<li class="cd-label">&copy;myspeec-<?= date('y')?></li>
			<li class="action-btn"><a href="" class="card-link">Refresh</a></li>

			</ul>
		</nav>
<!--
		<div class="content-wrapper">
			<h1>Responsive Sidebar Navigation</h1>
		</div>  .content-wrapper -->
<!--	</main> --> <!-- .cd-main-content -->